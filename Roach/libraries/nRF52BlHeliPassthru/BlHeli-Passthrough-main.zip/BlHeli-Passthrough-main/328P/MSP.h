
uint8_t MSP_Check(uint8_t MSP_buf[], uint8_t buf_size);
