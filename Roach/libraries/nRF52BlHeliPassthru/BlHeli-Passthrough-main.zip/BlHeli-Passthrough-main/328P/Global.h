
extern uint8_t serial_rx[300];
extern uint8_t ble_rx[300];

extern bool Enable4Way;
extern bool EnablePasstrough;
//extern bool ESC_OK;
extern bool ESC_CRC;
