
uint16_t Check_4Way(uint8_t buf[]);
uint16_t _crc_xmodem_update (uint16_t crc, uint8_t data);
