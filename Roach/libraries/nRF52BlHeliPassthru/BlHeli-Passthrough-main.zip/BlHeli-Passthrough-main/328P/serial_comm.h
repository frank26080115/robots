/*
 * Serial Communication
 * - for BlHeli
 */

void process_serial(void);
