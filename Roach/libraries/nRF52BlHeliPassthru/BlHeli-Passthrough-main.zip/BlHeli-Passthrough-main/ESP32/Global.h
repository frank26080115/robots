
#define SERVO_OUT 16

extern uint8_t serial_rx[300];
extern uint8_t ble_rx[300];

extern bool Enable4Way;
