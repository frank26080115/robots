

void init_ble(void);
void process_ble(void);
